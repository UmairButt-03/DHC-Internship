// src/App.js
import React, { Suspense, useEffect, useState } from 'react';
import { Provider, useDispatch, useSelector } from 'react-redux';
import store, { setWeatherData } from './store';
import { ThemeProvider, useTheme } from './ThemeContext';
import InfiniteScroll from 'react-infinite-scroll-component';
import debounce from 'lodash.debounce';

// Lazy loading the WeatherCard component
const WeatherCard = React.lazy(() => import('./WeatherCard'));

function App() {
  return (
    <Provider store={store}>
      <ThemeProvider>
        <WeatherApp />
      </ThemeProvider>
    </Provider>
  );
}

function WeatherApp() {
  const [query, setQuery] = useState('');
  const { darkMode, toggleDarkMode } = useTheme();
  const dispatch = useDispatch();
  const weatherData = useSelector((state) => state.weather.data);

  // Fetch weather data
  const fetchWeather = async (searchQuery) => {
    // Simulate API request (Replace with real API call)
    const fakeData = [
      { city: searchQuery || 'Lahore', temp: '28°C' },
      { city: 'New York', temp: '18°C' },
      { city: 'London', temp: '15°C' },
    ];
    dispatch(setWeatherData(fakeData));
  };

  // Debounced Search
  const handleSearch = debounce((e) => {
    setQuery(e.target.value);
    fetchWeather(e.target.value);
  }, 500);

  useEffect(() => {
    fetchWeather();
  }, []);

  const fetchMoreData = async () => {
    // Simulate fetching more data
    const moreData = [{ city: 'Sydney', temp: '20°C' }];
    dispatch(setWeatherData([...weatherData, ...moreData]));
  };

  return (
    <div style={{ background: darkMode ? '#333' : '#fff', color: darkMode ? '#fff' : '#000', minHeight: '100vh' }}>
      <header>
        <h1>Weather App</h1>
        <button onClick={toggleDarkMode}>Toggle Dark Mode</button>
        <input type="text" placeholder="Search city" onChange={handleSearch} />
      </header>
      <Suspense fallback={<div>Loading weather data...</div>}>
        <InfiniteScroll
          dataLength={weatherData.length}
          next={fetchMoreData}
          hasMore={true}
          loader={<h4>Loading...</h4>}
        >
          {weatherData.map((weather, index) => (
            <WeatherCard key={index} weather={weather} />
          ))}
        </InfiniteScroll>
      </Suspense>
    </div>
  );
}

export default App;
