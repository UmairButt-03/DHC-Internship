// src/WeatherCard.js
import React from 'react';

const WeatherCard = React.memo(({ weather }) => {
  return (
    <div style={{ border: '1px solid #ddd', margin: '10px', padding: '10px' }}>
      <h3>{weather.city}</h3>
      <p>{weather.temp}</p>
    </div>
  );
});

export default WeatherCard;
