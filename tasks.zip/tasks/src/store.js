// src/store.js
import { configureStore, createSlice } from '@reduxjs/toolkit';

// Create weather slice
const weatherSlice = createSlice({
  name: 'weather',
  initialState: {
    data: [], // Weather data
  },
  reducers: {
    setWeatherData: (state, action) => {
      state.data = action.payload;
    },
  },
});

// Export actions and reducer
export const { setWeatherData } = weatherSlice.actions;

const store = configureStore({
  reducer: {
    weather: weatherSlice.reducer,
  },
});

export default store;
