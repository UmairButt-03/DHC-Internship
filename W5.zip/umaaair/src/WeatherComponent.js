import React, { useState, useEffect } from 'react';

const WeatherComponent = ({ weatherData }) => {
  const [page, setPage] = useState(1);
  const [weatherHistory, setWeatherHistory] = useState([]);

  useEffect(() => {
    if (weatherData) {
      setWeatherHistory((prevHistory) => [...prevHistory, weatherData]);
    }
  }, [weatherData]);

  const loadMore = () => {
    setPage((prevPage) => prevPage + 1);
    // Fetch more weather data if API supports history, otherwise append data to history
  };

  return (
    <div>
      <h2>Weather Information</h2>
      {weatherHistory.slice(0, page * 5).map((data, index) => (
        <div key={index}>
          <p>City: {data.name}</p>
          <p>Temperature: {data.main.temp}°C</p>
        </div>
      ))}
      <button onClick={loadMore}>Load more</button>
    </div>
  );
};

export default React.memo(WeatherComponent);
