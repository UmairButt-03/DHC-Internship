import React, { useState, Suspense, useContext, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchWeather } from './WeatherComponent';
import { ThemeContext, ThemeProvider } from './ThemeContext';

const WeatherComponent = React.lazy(() => import('./WeatherComponent'));
const SearchInput = React.memo(({ onSearch }) => {
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      onSearch(searchTerm);
    }, 500); // Debounce timeout of 500ms

    return () => clearTimeout(delayDebounceFn);
  }, [searchTerm, onSearch]);

  return (
    <input
      type="text"
      placeholder="Search city"
      value={searchTerm}
      onChange={(e) => setSearchTerm(e.target.value)}
    />
  );
});

function App() {
  const dispatch = useDispatch();
  const weatherData = useSelector((state) => state.weather.data);
  const { theme, toggleTheme } = useContext(ThemeContext);

  const handleSearch = (city) => {
    dispatch(fetchWeather(city));
  };

  return (
    <ThemeProvider>
      <div className={`App ${theme}`}>
        <button onClick={toggleTheme}>
          Toggle to {theme === 'light' ? 'dark' : 'light'} mode
        </button>

        <SearchInput onSearch={handleSearch} />

        <Suspense fallback={<div>Loading weather...</div>}>
          <WeatherComponent weatherData={weatherData} />
        </Suspense>
      </div>
    </ThemeProvider>
  );
}

export default App;
