import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';

const apiKey = '09340b116992caa52dca89df1c7400b3'; // Use your API key here
const weatherApiUrl = 'https://api.openweathermap.org/data/2.5/weather';

export const fetchWeather = createAsyncThunk('weather/fetchWeather', async (city) => {
  const response = await fetch(`${weatherApiUrl}?q=${city}&appid=${apiKey}&units=metric`);
  const data = await response.json();
  if (response.ok) {
    return data;
  } else {
    throw new Error(data.message || 'Failed to fetch weather data');
  }
});

const weatherSlice = createSlice({
  name: 'weather',
  initialState: {
    data: null,
    status: 'idle',
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchWeather.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(fetchWeather.fulfilled, (state, action) => {
        state.status = 'succeeded';
        state.data = action.payload;
      })
      .addCase(fetchWeather.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.error.message;
      });
  }
});

export default weatherSlice.reducer;
